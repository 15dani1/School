
//Rahul Dani September 29, 2017
import java.text.DecimalFormat;
import java.util.*;

public class Blackjack {
                                                // initializing variables.
    private static int numOne = 0;
    private static int totalGames = 0;
    private static int playerWins = 0;
    private static int tieGames = 0;
    private static int dealerNumber = 0;
    private static int winsDealer = 0;
    private static int playerHand = 0;
    private static double percentWins = 0;
    private static Scanner scr = new Scanner(System.in);

    public static int userInput() { //The user inputs their preference from the menu.

        System.out.println("1. Get another card"); //The player's menu.
        System.out.println("2. Hold Hand");
        System.out.println("3. Print statistics");
        System.out.println("4. Exit");
        System.out.println("");
        System.out.print("Choose an option: ");

        int playerInput=0;
        try {
            playerInput = scr.nextInt();
        }
        catch (InputMismatchException e) { //Makes sure that only integers are inputted.
            scr.nextLine();
            System.out.println("");
            System.out.println("Invalid input!");
            System.out.println("Please enter an integer value between 1 and 4.");
            System.out.println("");
            return userInput();
        }

        if (playerInput <= 0 || playerInput > 4) { //Makes sure that the inputs inputted are in the range.

            System.out.println("");
            System.out.println("Invalid input!");
            System.out.println("Please enter an integer value between 1 and 4.");
            System.out.println("");
            return userInput();
        }
        System.out.println("");
        return playerInput;
    }

    public static void playerHit(int playerInput) { //The input value is processed in playerHit.

        switch (playerInput) {

            case 1:
                startGame(); //Player hits.
                break;

            case 2:
                holdHand(); //Player holds his hand.
                break;

            case 3:
                gameStats(); //Player is shown game statistics.
                break;

            case 4:
                System.exit(1); //Player decides to quit the game.
                break;
        }
    }

    public static void startGame() { //The game begins here.

        numOne = (int) (Math.random() * 13) + 1; //Random numbers for player is generated.

        if (numOne == 1) {

            System.out.println("Your card is an ACE!");
        } else if (numOne >= 2 && numOne <= 10) {

            System.out.println("Your card is a " + numOne + "!");

        } else if (numOne == 11) {

            System.out.println("Your card is a JACK!");
        } else if (numOne == 12) {

            System.out.println("Your card is a QUEEN!");

        } else if (numOne == 13) {

            System.out.println("Your card is a KING!");
        }

        if (numOne >= 10) {

            numOne = 10;
        }
        playerHand = playerHand + numOne;
        System.out.println("Your hand is: " + playerHand); //Displays player's hand.
        System.out.println("");

        if (playerHand > 21) {
            System.out.println("You exceeded 21! You lose :("); //Player crosses 21.
            System.out.println("");
            winsDealer++;
        }

        else if (playerHand == 21) {
            System.out.println("Blackjack, you win!"); //Player gets 21.
            System.out.println("");
            playerWins++;
        }

        else {
            playerHit(userInput()); //Goes to the switch case and uses player's number choice.
        }
    }
        public static void holdHand () { //This is run when player hold his hand.

        System.out.println("Dealer's hand: " + dealerNumber); //Displays dealer's hand.
        System.out.println("Your hand is: " + playerHand);   //Displays player's hand.
        System.out.println("");

        if (dealerNumber > 21 || playerHand > dealerNumber) {  //Conditions in which player wins.

            System.out.println("You win!");
            System.out.println("");
            playerWins++;

        } else if (dealerNumber == playerHand) { //Conditions where the game is tied.

            System.out.println("It's a tie! No one wins!");
            System.out.println("");
            tieGames++;

        } else if (dealerNumber > playerHand) { //Conditions where the dealer wins.

            System.out.println("Dealer wins!");
            System.out.println("");
            winsDealer++;
        }
    }

    public static void gameStats() { //Displays the statistics of game played.

        System.out.println("Number of Player wins: " + playerWins);
        System.out.println("Number of Dealer wins: " + winsDealer);
        System.out.println("Number of tie games: " + tieGames);
        System.out.println("Total # of games played is: " + totalGames);

        percentWins = ((double) playerWins / (double) totalGames) * 100;
        DecimalFormat percentWinsFormat = new DecimalFormat("#.0");

        System.out.println("Percentage of Player wins: " + percentWinsFormat.format(percentWins));
        System.out.println("");
        userInput();
    }

    public static void main(String[] args) { //Main method of the program.

        int x = 0;

        while (true) {
            x++;
            playerHand = 0;
            dealerNumber = (int) (Math.random() * 11) + 16;
            System.out.println("START GAME #" + x); //Shows game number.
            System.out.println("");
            startGame(); //Starts the game.
            totalGames++; //Shows total games played.
        }
    }
}


